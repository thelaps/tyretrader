<?php
/**
 * Created by JetBrains PhpStorm.
 * User: alice
 * Date: 10.10.12
 * Time: 2:22
 * To change this template use File | Settings | File Templates.
 */
Abstract Class controller extends connector{
    public $viewData;
    abstract function render();
}