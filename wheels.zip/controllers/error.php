<?php
/**
 * Created by JetBrains PhpStorm.
 * User: noya
 * Date: 13.02.13
 * Time: 20:32
 * To change this template use File | Settings | File Templates.
 */
class error extends controller{

    public function render(){
        return 'error.tpl';
    }
}