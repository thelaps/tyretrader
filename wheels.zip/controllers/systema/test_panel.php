<?php
/**
 * Created by JetBrains PhpStorm.
 * User: alice
 * Date: 10.10.12
 * Time: 2:25
 * To change this template use File | Settings | File Templates.
 */
class test_panel extends controller{

    public function render(){
        $get=$this->getRequest('get');
        if(isset($get['fnc'])){
            $isComplete=false;
            switch ($get['fnc']){
                case 'attach':
                    $isComplete=$this->runQuery();
                    break;
            }
            print json_encode(array('status'=>$isComplete));
        }else{

        }
        print $this->sError;
    }

    public function runQuery(){
        $base=$this->WheelModel;

        $dbo=App::DBO();
        foreach($base as $key=>$val){
            $alias=$this->getAliasID($val['MName']);

            $query='INSERT INTO wheel_models
                    (manufacturer_id,name)
                    VALUES
                    ('.$alias.',\''.$val['Name'].'\')';
            $stmt = $dbo->prepare($query);
            $stmt->execute();

        }
    }

    public function getAliasID($name){
        $viewData=array();
        $dbo=App::DBO();
        $query='SELECT id FROM wheel_manufacturers WHERE name LIKE \'%'.$name.'%\'';
        $stmt = $dbo->prepare($query);
        $stmt->execute();
        while($row = $stmt->fetch(PDO::FETCH_OBJ)){
            $viewData=$row->id;
        }
        return $viewData;
    }

public $WheelModel = array(
array('Name' => 'Plix','MName' => 'Alutec'),
array('Name' => 'Boost','MName' => 'Alutec'),
array('Name' => 'Blizzard','MName' => 'Alutec'),
array('Name' => 'Blade','MName' => 'Alutec'),
array('Name' => 'Black Sun','MName' => 'Alutec'),
array('Name' => 'B','MName' => 'Alutec'),
array('Name' => 'Nitro','MName' => 'Alutec'),
array('Name' => 'Magnum','MName' => 'Alutec'),
array('Name' => 'Lazor','MName' => 'Alutec'),
array('Name' => 'Helix','MName' => 'Alutec'),
array('Name' => 'Grip','MName' => 'Alutec'),
array('Name' => 'V','MName' => 'Alutec'),
array('Name' => 'Toxic','MName' => 'Alutec'),
array('Name' => 'Tornado','MName' => 'Alutec'),
array('Name' => 'Storm','MName' => 'Alutec'),
array('Name' => 'Energy T','MName' => 'Alutec'),
array('Name' => 'Spyke','MName' => 'Alutec'),
array('Name' => 'Energy','MName' => 'Alutec'),
array('Name' => 'Shark','MName' => 'Alutec'),
array('Name' => 'Ecstasy','MName' => 'Alutec'),
array('Name' => 'E','MName' => 'Alutec'),
array('Name' => 'Zero','MName' => 'Alutec'),
array('Name' => 'Dynamite','MName' => 'Alutec'),
array('Name' => 'Xplosive 5','MName' => 'Alutec'),
array('Name' => 'Xplosive 4','MName' => 'Alutec'),
array('Name' => 'Cult','MName' => 'Alutec'),
array('Name' => 'Poison cup','MName' => 'Alutec'),
array('Name' => 'Poison','MName' => 'Alutec'),
array('Name' => '401','MName' => 'Carre'),
array('Name' => '313','MName' => 'Carre'),
array('Name' => '307','MName' => 'Carre'),
array('Name' => '580','MName' => 'Carre'),
array('Name' => '516','MName' => 'Carre'),
array('Name' => '515','MName' => 'Carre'),
array('Name' => '514','MName' => 'Carre'),
array('Name' => '510','MName' => 'Carre'),
array('Name' => '509','MName' => 'Carre'),
array('Name' => '508','MName' => 'Carre'),
array('Name' => '506','MName' => 'Carre'),
array('Name' => '504','MName' => 'Carre'),
array('Name' => '503','MName' => 'Carre'),
array('Name' => '501','MName' => 'Carre'),
array('Name' => '410','MName' => 'Carre'),
array('Name' => '409B','MName' => 'Carre'),
array('Name' => '409A','MName' => 'Carre'),
array('Name' => '405','MName' => 'Carre'),
array('Name' => '404','MName' => 'Carre'),
array('Name' => 'PD8','MName' => 'Lenso'),
array('Name' => 'PD7','MName' => 'Lenso'),
array('Name' => 'PD6','MName' => 'Lenso'),
array('Name' => 'Granzo','MName' => 'Lenso'),
array('Name' => 'Grande 2','MName' => 'Lenso'),
array('Name' => 'Grande 1','MName' => 'Lenso'),
array('Name' => 'Campo','MName' => 'Rial'),
array('Name' => 'Oslo','MName' => 'Rial'),
array('Name' => 'Roma','MName' => 'Rial'),
array('Name' => 'Riga','MName' => 'Rial'),
array('Name' => 'Ravenna','MName' => 'Rial'),
array('Name' => 'Davos','MName' => 'Rial'),
array('Name' => 'Porto','MName' => 'Rial'),
array('Name' => 'Como','MName' => 'Rial'),
array('Name' => 'W568','MName' => 'WSP Italy'),
array('Name' => 'W2406','MName' => 'WSP Italy'),
array('Name' => 'W3602','MName' => 'WSP Italy'),
array('Name' => 'W661','MName' => 'WSP Italy'),
array('Name' => 'W538','MName' => 'WSP Italy'),
array('Name' => 'W954','MName' => 'WSP Italy'),
array('Name' => 'W150','MName' => 'WSP Italy'),
array('Name' => 'W567','MName' => 'WSP Italy'),
array('Name' => 'W2405','MName' => 'WSP Italy'),
array('Name' => 'W3601','MName' => 'WSP Italy'),
array('Name' => 'W660','MName' => 'WSP Italy'),
array('Name' => 'W536','MName' => 'WSP Italy'),
array('Name' => 'W953','MName' => 'WSP Italy'),
array('Name' => 'W144','MName' => 'WSP Italy'),
array('Name' => 'W566','MName' => 'WSP Italy'),
array('Name' => 'W2404','MName' => 'WSP Italy'),
array('Name' => 'W3502','MName' => 'WSP Italy'),
array('Name' => 'W659','MName' => 'WSP Italy'),
array('Name' => 'W535','MName' => 'WSP Italy'),
array('Name' => 'W952','MName' => 'WSP Italy'),
array('Name' => 'W142','MName' => 'WSP Italy'),
array('Name' => 'W565','MName' => 'WSP Italy'),
array('Name' => 'W2403','MName' => 'WSP Italy'),
array('Name' => 'W3404','MName' => 'WSP Italy'),
array('Name' => 'W658','MName' => 'WSP Italy'),
array('Name' => 'W534','MName' => 'WSP Italy'),
array('Name' => 'W951','MName' => 'WSP Italy'),
array('Name' => 'W140','MName' => 'WSP Italy'),
array('Name' => 'W564','MName' => 'WSP Italy'),
array('Name' => 'W2402','MName' => 'WSP Italy'),
array('Name' => 'W3403','MName' => 'WSP Italy'),
array('Name' => 'W657','MName' => 'WSP Italy'),
array('Name' => 'W533','MName' => 'WSP Italy'),
array('Name' => 'W950','MName' => 'WSP Italy'),
array('Name' => 'W1052','MName' => 'WSP Italy'),
array('Name' => 'W563','MName' => 'WSP Italy'),
array('Name' => 'W237','MName' => 'WSP Italy'),
array('Name' => 'W654','MName' => 'WSP Italy'),
array('Name' => 'W3402','MName' => 'WSP Italy'),
array('Name' => 'W532','MName' => 'WSP Italy'),
array('Name' => 'W912','MName' => 'WSP Italy'),
array('Name' => 'W1051','MName' => 'WSP Italy'),
array('Name' => 'W562','MName' => 'WSP Italy'),
array('Name' => 'W234','MName' => 'WSP Italy'),
array('Name' => 'W653','MName' => 'WSP Italy'),
array('Name' => 'W3401','MName' => 'WSP Italy'),
array('Name' => 'W531','MName' => 'WSP Italy'),
array('Name' => 'W911','MName' => 'WSP Italy'),
array('Name' => 'W1050','MName' => 'WSP Italy'),
array('Name' => 'W561','MName' => 'WSP Italy'),
array('Name' => 'W232','MName' => 'WSP Italy'),
array('Name' => 'W652','MName' => 'WSP Italy'),
array('Name' => 'W315','MName' => 'WSP Italy'),
array('Name' => 'W530','MName' => 'WSP Italy'),
array('Name' => 'W910','MName' => 'WSP Italy'),
array('Name' => 'W1008','MName' => 'WSP Italy'),
array('Name' => 'W560','MName' => 'WSP Italy'),
array('Name' => 'W231','MName' => 'WSP Italy'),
array('Name' => 'W651','MName' => 'WSP Italy'),
array('Name' => 'W314','MName' => 'WSP Italy'),
array('Name' => 'W4501','MName' => 'WSP Italy'),
array('Name' => 'W677','MName' => 'WSP Italy'),
array('Name' => 'W1006','MName' => 'WSP Italy'),
array('Name' => 'W559','MName' => 'WSP Italy'),
array('Name' => 'W221','MName' => 'WSP Italy'),
array('Name' => 'W650','MName' => 'WSP Italy'),
array('Name' => 'W257','MName' => 'WSP Italy'),
array('Name' => 'W3904','MName' => 'WSP Italy'),
array('Name' => 'W676','MName' => 'WSP Italy'),
array('Name' => 'W558','MName' => 'WSP Italy'),
array('Name' => 'W163','MName' => 'WSP Italy'),
array('Name' => 'W649','MName' => 'WSP Italy'),
array('Name' => 'W256','MName' => 'WSP Italy'),
array('Name' => 'W3903','MName' => 'WSP Italy'),
array('Name' => 'W675','MName' => 'WSP Italy'),
array('Name' => 'W557','MName' => 'WSP Italy'),
array('Name' => 'W162','MName' => 'WSP Italy'),
array('Name' => 'W648','MName' => 'WSP Italy'),
array('Name' => 'W255','MName' => 'WSP Italy'),
array('Name' => 'W3902','MName' => 'WSP Italy'),
array('Name' => 'W674','MName' => 'WSP Italy'),
array('Name' => 'W556','MName' => 'WSP Italy'),
array('Name' => 'W161','MName' => 'WSP Italy'),
array('Name' => 'W647','MName' => 'WSP Italy'),
array('Name' => 'W253','MName' => 'WSP Italy'),
array('Name' => 'W3901','MName' => 'WSP Italy'),
array('Name' => 'W673','MName' => 'WSP Italy'),
array('Name' => 'W555','MName' => 'WSP Italy'),
array('Name' => 'W160','MName' => 'WSP Italy'),
array('Name' => 'W646','MName' => 'WSP Italy'),
array('Name' => 'W252','MName' => 'WSP Italy'),
array('Name' => 'W3803','MName' => 'WSP Italy'),
array('Name' => 'W672','MName' => 'WSP Italy'),
array('Name' => 'W554','MName' => 'WSP Italy'),
array('Name' => 'W158','MName' => 'WSP Italy'),
array('Name' => 'W645','MName' => 'WSP Italy'),
array('Name' => 'W251','MName' => 'WSP Italy'),
array('Name' => 'W3802','MName' => 'WSP Italy'),
array('Name' => 'W671','MName' => 'WSP Italy'),
array('Name' => 'W552','MName' => 'WSP Italy'),
array('Name' => 'W157','MName' => 'WSP Italy'),
array('Name' => 'W644','MName' => 'WSP Italy'),
array('Name' => 'W250','MName' => 'WSP Italy'),
array('Name' => 'W3801','MName' => 'WSP Italy'),
array('Name' => 'W670','MName' => 'WSP Italy'),
array('Name' => 'W551','MName' => 'WSP Italy'),
array('Name' => 'W156','MName' => 'WSP Italy'),
array('Name' => 'W643','MName' => 'WSP Italy'),
array('Name' => 'W2411','MName' => 'WSP Italy'),
array('Name' => 'W3702','MName' => 'WSP Italy'),
array('Name' => 'W669','MName' => 'WSP Italy'),
array('Name' => 'W550','MName' => 'WSP Italy'),
array('Name' => 'W155','MName' => 'WSP Italy'),
array('Name' => 'W642','MName' => 'WSP Italy'),
array('Name' => 'W2410','MName' => 'WSP Italy'),
array('Name' => 'W3701','MName' => 'WSP Italy'),
array('Name' => 'W668','MName' => 'WSP Italy'),
array('Name' => 'W546','MName' => 'WSP Italy'),
array('Name' => 'W154','MName' => 'WSP Italy'),
array('Name' => 'W638','MName' => 'WSP Italy'),
array('Name' => 'W2409','MName' => 'WSP Italy'),
array('Name' => 'W3605','MName' => 'WSP Italy'),
array('Name' => 'W667','MName' => 'WSP Italy'),
array('Name' => 'W545','MName' => 'WSP Italy'),
array('Name' => 'W153','MName' => 'WSP Italy'),
array('Name' => 'W637','MName' => 'WSP Italy'),
array('Name' => 'W2408','MName' => 'WSP Italy'),
array('Name' => 'W3604','MName' => 'WSP Italy'),
array('Name' => 'W663','MName' => 'WSP Italy'),
array('Name' => 'W544','MName' => 'WSP Italy'),
array('Name' => 'W956','MName' => 'WSP Italy'),
array('Name' => 'W152','MName' => 'WSP Italy'),
array('Name' => 'W635','MName' => 'WSP Italy'),
array('Name' => 'W2407','MName' => 'WSP Italy'),
array('Name' => 'W3603','MName' => 'WSP Italy'),
array('Name' => 'W662','MName' => 'WSP Italy'),
array('Name' => 'W539','MName' => 'WSP Italy'),
array('Name' => 'W955','MName' => 'WSP Italy'),
array('Name' => 'W151','MName' => 'WSP Italy')
);
    
}
