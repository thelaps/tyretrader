<?php
/**
 * Created by JetBrains PhpStorm.
 * User: alice
 * Date: 10.10.12
 * Time: 2:25
 * To change this template use File | Settings | File Templates.
 */
class api_panel extends controller{

    public $sError=null;

    private $showData=null;

    public function render(){
        $get=$this->getRequest('get');
        if(isset($get['fnc'])){
            $isComplete=false;
            $data=null;
            switch ($get['fnc']){
                case 'modify':
                    $isComplete=$this->api_modify();
                    break;
                case 'show':
                    $isComplete=$this->api_show();
                    break;
                case 'add':
                    $isComplete=$this->api_add();
                    break;
            }
            $response=array(
                'status'=>$isComplete,
                'data'=>$this->showData,
                'getQuery'=>$get,
                'postQuery'=>$this->getRequest('post')
            );
            App::ajax(json_encode($response));
        }else{
            //$this->viewData['oSearchTemplates']=$this->attachSearchTemplates();;
            //return 'price.tpl';
        }
        App::ajax($this->sError);
    }

    public function api_add(){
        $post=$this->getRequest('post');
        if(isset($post['fnc'])){
            switch ($post['fnc']){
                case 'manufacturer':
                    $this->showData=$this->addManufacturer();
                    break;
                case 'model':
                    $this->showData=$this->addModel();
                    break;
                case 'price':
                    $this->showData=$this->addPrice();
                    break;
                case 'parameter':
                    $this->showData=$this->addParameter();
                    break;
            }
            return true;
        }
        return false;
    }

    private function addParameter(){
        $post = $this->getRequest('post');
        if(isset($post['type'])){
            if ($post['type']==41) {
                //model
            } elseif ($post['type']==42) {
                //manufacturer
            } else {
                //parameters
            }
        }
        return true;
    }

    private function addPrice(){
        $post = $this->getRequest('post');
        if(isset($post['priceData'])){
            $decoded = json_decode($post['priceData']);
            if($decoded){
                $priceExtractor = App::newJump('priceExtractor','modules');
                return $priceExtractor->DBOExtract($decoded);
            }
            return false;
        }
        return false;
    }

    private function addManufacturer(){
        $post=$this->getRequest('post');
        $synonym=$post['synonym'];
        $manufacturer=$post['manufacturer'];
        if(!empty($manufacturer['name']) && $manufacturer['type']!=null){
            $dbo=App::DBO();
            $query='INSERT INTO wheel_manufacturers
                    (name)
                    VALUES
                    (\''.$manufacturer['name'].'\')';
            $stmt = $dbo->prepare($query);
            $stmt->execute();

            $id=$dbo->lastInsertId();

            $dbo=App::DBO();
            $query='INSERT INTO wheel_manufacturers2type
                    (manufacturer_id,type)
                    VALUES
                    ('.$id.','.$manufacturer['type'].')';
            $stmt = $dbo->prepare($query);
            $stmt->execute();
            return array(
                'add'=>'model',
                'id'=>$id,
                'manufacturer'=>$this->getManufacturerById($id)
            );
        }elseif(!empty($synonym['synonym']) && $synonym['manufacturer_id']!=null){
            $dbo=App::DBO();
            $query='INSERT INTO wheel_synonym2manufacturers
                    (manufacturer_id,synonym)
                    VALUES
                    ('.$synonym['manufacturer_id'].',\''.$synonym['synonym'].'\')';
            $stmt = $dbo->prepare($query);
            $stmt->execute();
            $id=$dbo->lastInsertId();
            return array(
                'add'=>'model',
                'id'=>$id,
                'manufacturer'=>$this->getManufacturerById($id)
            );
        }
        return false;
    }

    private function addManufacturerSynonym($id){
        $post=$this->getRequest('post');
        $synonym=$post['synonym'];
        $dbo=App::DBO();
        $query='INSERT INTO wheel_synonym2manufacturers
                    (manufacturer_id,synonym)
                    VALUES
                    ('.$id.',\''.$synonym['synonym'].'\')';
        $stmt = $dbo->prepare($query);
        $stmt->execute();
        return true;
    }

    public function attachRawManufacturers(){
        $viewData=array();
        $dbo=App::DBO();
        $query='SELECT * FROM wheel_manufacturers
                INNER JOIN wheel_manufacturers2type
                WHERE wheel_manufacturers.id=wheel_manufacturers2type.manufacturer_id
                GROUP BY wheel_manufacturers.id';
        $stmt = $dbo->prepare($query);
        $stmt->execute();
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            $viewData[]=$row;
        }//"->datamodel" - pseudo storage. After commit this is not empty)
        return $viewData;
    }

    private function addModel(){
        $post=$this->getRequest('post');
        $model=$post['model'];
        $id=null;
        if($model['manufacturer_id']!=null && $model['name']!=null){
            $dbo=App::DBO();
            $query='INSERT INTO wheel_models
                    (manufacturer_id,name,description)
                    VALUES
                    ('.$model['manufacturer_id'].',\''.$model['name'].'\',NULL)';
            $stmt = $dbo->prepare($query);
            $stmt->execute();
            $id=$dbo->lastInsertId();
            $this->addModelSynonym($id);
        }elseif($model['id']!=null){
            $id=$model['id'];
            $this->addModelSynonym($id);
        }
        return array(
            'add'=>'model',
            'id'=>$id,
            'model'=>$this->getModelById($id)
        );
    }

    private function getModelById($id){
        $viewData=array();
        $dbo=App::DBO();
        $query='SELECT wheel_models.id,
                wheel_manufacturers.name as manufacturer,
                wheel_models.manufacturer_id,
                wheel_models.name as model
                FROM wheel_manufacturers
                INNER JOIN wheel_models
                ON wheel_manufacturers.id=wheel_models.manufacturer_id
                WHERE wheel_models.id='.$id.'';
        $stmt = $dbo->prepare($query);
        $stmt->execute();
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            $viewData=$row;
        }//"->datamodel" - pseudo storage. After commit this is not empty)
        return $viewData;
    }

    private function addModelSynonym($id){
        $post=$this->getRequest('post');
        $synonym=$post['synonym'];
        if(!empty($synonym['synonym']) && $id!=null){
            $dbo=App::DBO();
            $query='INSERT INTO wheel_synonym2model
                    (model_id,synonym)
                    VALUES
                    ('.$id.',\''.$synonym['synonym'].'\')';
            $stmt = $dbo->prepare($query);
            $stmt->execute();
            return true;
        }
        return false;
    }

    public function api_show(){
        $get=$this->getRequest('get');
        if(isset($get['case'])){
            switch ($get['case']){
                case 'synonym_list':
                    $this->showData=$this->getSynonymList();
                    break;
            }
            return true;
        }
        return false;
    }

    private function getSynonymList(){
        $params=$this->getModel('wheel_synonymlist'); //Getter for datamodel classes -> we have an object of class
        $params->commit(); //Commit - set data to storage from model - this able us to controlling models
        return $params->datamodel; //"->datamodel" - pseudo storage. After commit this is not empty)
    }

    private function getManufacturerById($id,$isSyn=false){
        $viewData=array();
        if($id!=null){
            $dbo=App::DBO();
            if($isSyn){
            $query='SELECT wheel_manufacturers.id, wheel_manufacturers.name FROM wheel_manufacturers
                INNER JOIN wheel_synonym2manufacturers
                ON wheel_synonym2manufacturers.manufacturer_id=wheel_manufacturers.id
                WHERE wheel_synonym2manufacturers.id='.$id.'';
            }else{
            $query='SELECT wheel_manufacturers.id, wheel_manufacturers.name FROM wheel_manufacturers
                WHERE wheel_manufacturers.id='.$id.'';
            }
            $stmt = $dbo->prepare($query);
            $stmt->execute();
            while($row = $stmt->fetch(PDO::FETCH_OBJ)){
                $viewData['name']=$row->name;
                $viewData['id']=$row->id;
            }
        }
        return $viewData;
    }

    /*
     * <input type="hidden" name="fnc" value="">
        <input type="hidden" name="synonym[id]" value="">
        <input type="text" name="synonym[synonym]" placeholder="Синоним" />
        <select name="synonym[dict]">*/

    public function api_modify(){
        $post=$this->getRequest('post');
        if(isset($post['fnc'])){
            switch ($post['fnc']){
                case 'add':
                    $this->showData=$this->addSynonym();
                    break;
                case 'edit':
                    $this->showData=$this->editSynonym();
                    break;
            }
        }
    }

    private function addSynonym(){
        $post=$this->getRequest('post');

        $type=$post['type'];

        if($type==41 || $type==42){
            $status=false;
            $id=$post['synonym']['dict'];
            switch($type){
                case 41:
                    $status=$this->addModelSynonym($id);
                    break;
                case 42:
                    $status=$this->addManufacturerSynonym($id);
                    break;
            }
            return $status;
        }else{
            $field=$post['synonym'];
            if($field['synonym']!=null && $field['dict']!=null){
                $dbo=App::DBO();
                $query='INSERT INTO wheel_synonym2dict
                        (dict_id,synonym)
                        VALUES
                        ('.$field['dict'].',\''.$field['synonym'].'\')';
                $stmt = $dbo->prepare($query);
                $stmt->execute();
                return $query;
            }
        }

        return false;
    }

    private function editSynonym(){
        $post=$this->getRequest('post');

        $type=$post['type'];

        if($type==41 || $type==42){
            $status=false;
            switch($type){
                case 41:
                    $status=$this->editModelSynonym();
                    break;
                case 42:
                    $status=$this->editManufacturerSynonym();
                    break;
            }
            return $status;
        }else{
            $field=$post['synonym'];
            if($field['id']!=null && $field['synonym']!=null && $field['dict']!=null){
                $dbo=App::DBO();
                $query='UPDATE wheel_synonym2dict
                        SET dict_id='.$field['dict'].' ,synonym=\''.$field['synonym'].'\'
                        WHERE id='.$field['id'];
                $stmt = $dbo->prepare($query);
                $stmt->execute();
                return true;
            }
        }

        return false;
    }

    private function editModelSynonym(){
        $post=$this->getRequest('post');
        $synonym=$post['synonym'];
        if($synonym['id']!=null && !empty($synonym['synonym']) && $synonym['dict']!=null){
            $dbo=App::DBO();
            $query='UPDATE wheel_synonym2model
                    SET model_id='.$synonym['dict'].',
                    synonym=\''.$synonym['synonym'].'\'
                    WHERE id='.$synonym['id'].'';
            $stmt = $dbo->prepare($query);
            $stmt->execute();
            return $query;
        }
    }

    private function editManufacturerSynonym(){
        $post=$this->getRequest('post');
        $synonym=$post['synonym'];
        if($synonym['id']!=null && !empty($synonym['synonym']) && $synonym['dict']!=null){
            $dbo=App::DBO();
            $query='UPDATE wheel_synonym2manufacturers
                    SET manufacturer_id='.$synonym['dict'].',
                    synonym=\''.$synonym['synonym'].'\'
                    WHERE id='.$synonym['id'].'';
            $stmt = $dbo->prepare($query);
            $stmt->execute();
            return $query;
        }
    }
}