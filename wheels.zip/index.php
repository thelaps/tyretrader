<?php
$ts = microtime(true);


require 'core/app.php';

App::start();


$te = microtime(true);
$time = ($te - $ts);
//print_r($time);
?>
