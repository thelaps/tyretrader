/**
 * Created with JetBrains PhpStorm.
 * User: noya
 * Date: 13.05.13
 * Time: 19:46
 * To change this template use File | Settings | File Templates.
 */
$.extend({
    parser:{
        callback:$(document),
        collection:{
            obj:null,
            items:null,
            settings:null,
            tyres:null,
            wheels:null,
            search_templates:null,
            manufacturer_patterns:null
        },
        waitFor:0,
        waitFrom:0,
        accepted:null,
        notaccepted:new Array,
        process:function(){
            $('body').jPopup({isActive:true});
            //var form=$('form[name="priceProcessing"]');
            //var serialized=form.serialize();
            //var action=form.attr('action');
            var activated=$('.listIdent input[type="checkbox"]:checked');
            $.parser.collection.obj = new Array;
            $.parser.collection.items = new Array;
            activated.each(function(){
                var id=$(this).parent().attr('data-id');
                $.parser.collection.obj.push($('.listTab:eq('+id+')'));
                $.parser.collection.items.push(id);
            });
            $.parser.setSettings();

            $.parser.run();

            $.parser.callback.bind({
                runEnd:function(){
                    if($.parser.notaccepted!=null){
                        $.parser.buildErrorList();
                    }
                    $('body').jPopup({isActive:false});
                }
            });
        },setSettings:function(){
            $.parser.collection.settings = new Array;
            var extraSettings=$('.extraSettings');
            var settingsTotal=$.parser.collection.items.length;
            var settingsItem=$.parser.collection.items;
            for(i=0; i<settingsTotal; i++){
                var settingItem=extraSettings.children('li[data-id="'+settingsItem[i]+'"]');
                var settingObj={
                    type:settingItem.find('[name="type[]"]').val(),
                    existing:settingItem.find('[name="existing[]"]').val(),
                    excluding:settingItem.find('[name="excluding[]"]').val(),
                    including:settingItem.find('[name="including[]"]').val(),
                    manufacturer:settingItem.find('[name="manufacturer[]"]').val(),
                    currency:settingItem.find('[name="currency[]"]').val(),
                    parameter:null
                }
                settingObj.parameter=new Array;
                settingItem.find('[name="parameter[][]"]').each(function(){
                    settingObj.parameter.push($(this).val());
                });

                $.parser.collection.settings.push(settingObj);
            }
        },run:function(){
            var oObj=$.parser.collection.obj;
            var exploded=new Array;
            $.parser.accepted = new Array;
            $.parser.notaccepted = new Array;
            for(var domKey in oObj){
                //exploded.push($.parser.explode(oObj[domKey],domKey));
                var keyList=$.parser.explode(oObj[domKey],domKey,exploded);
                exploded=keyList;
            }
            $.parser.callback.bind({
                explodeEnd:function(){
                    var exLength=exploded.length;
                    $.jPopupChange('В очереди на обработку: '+exLength+' строк');
                    setTimeout(function(){
                        console.log('starting parsing');
                        var counter=0;
                        var interval=setInterval(function(){
                            $.jPopupChange('Обработано: '+counter+' из '+exploded.length+' строк');
                            var storage=exploded[counter];
                            var storageKey=(storage!=undefined)?storage.key:null;
                            var storageValue=(storageKey!=null)?localStorage.getItem(storageKey):null;
                            var template=(storage!=undefined)?storage.tab:null;
                            if(counter<exploded.length && template!=null){
                                $.parser.accepted[hex_md5(storageValue)]=$.parser.checkIn(storageValue,template);
                                counter++;
                                localStorage.removeItem(storageKey);
                            }else{
                                $.jPopupChange('Обработано');
                                $.parser.callback.trigger('runEnd');
                                clearInterval(interval);
                            }
                        },80);
                    },1000);
                }
            });
        },explode:function(obj,domKey,exploded){
            var rows=obj.find('tr:not(.exclude)"');
            $.parser.waitFrom=rows.length+$.parser.waitFrom;
            rows.each(function(xkey){
                var self = this;
                var timeout=setTimeout(function(){
                    $.parser.waitFor=($.parser.waitFor+1);
                    var key='parser_items_'+domKey+'_'+xkey;
                    var cells=$(self).find('td');
                    var imploded='';
                    cells.each(function(key){
                        var delimiter=(key==0)?'':' | ';
                        imploded+=delimiter+$(this).text();
                    });
                    localStorage.setItem(key, imploded);
                    var tabbing={
                        key:key,
                        tab:domKey,
                        row:xkey
                    }
                    exploded.push(tabbing);

                    $.jPopupChange('Добавляю  '+$.parser.waitFor+' строку в очередь из '+$.parser.waitFrom+' строк');
                    var isTrigg=($.parser.waitFrom==$.parser.waitFor)?true:false;
                    if(isTrigg){
                        $.parser.callback.trigger('explodeEnd');
                        clearTimeout(timeout);
                    }

                }, xkey*30);
            });
            return exploded;
        },
        checkIn:function(strSource,domKey){
            var settings=$.parser.collection.settings[domKey];

            var extraCell=strSource.split('|');



            //Типоразмеры
            var newstr = $.parser.regulate(strSource,domKey,0);

            //Индексы Скорость-нагрузка
            if(newstr!=null){
                var strSourceNext=strSource.replace(new RegExp(newstr[0],'g'),'');
                var indexes = $.parser.regulate(strSourceNext,domKey,1);
            }else{
                var strSourceNext=null;
                var indexes=null;
            }

            //Производитель
            /*strSourceNext=strSourceNext.replace(new RegExp(indexes[0],'g'),'');
            var manufacturer = $.parser.regulate(strSourceNext,domKey,1);*/



            //settings.type
            //var parameters=$.extraTab.parameters[settings.type];

            var checkedParameters=settings.parameter;

            var attachParameters=$.parser.getValuesByParameter(extraCell,checkedParameters,strSource);

            if(newstr!=null){
                var tmpObj={
                    currency:settings.currency,
                    existing:settings.existing,
                    //R колеса: 3,9 ? диски: 13
                    //W колеса: 4,6 ? диски: 12
                    //H колеса: 5,7
                    //Si индекс скорости F - перед, B - зад
                    //Sw индекс нагрузки F - перед, B - зад
                    R:$.parser.getParameter(newstr, new Array(3,9,13)),
                    W:$.parser.getParameter(newstr, new Array(4,6,12)),
                    H:$.parser.getParameter(newstr, new Array(5,7)),
                    I:(newstr[10]!=null)?newstr[10]:null,
                    type:settings.type,
                    manufacturer:settings.manufacturer,
                    model:null,
                    Si:{
                        F:(indexes!=null && indexes[4]!=undefined)?indexes[4]:null,
                        B:(indexes!=null && indexes[7]!=undefined)?indexes[7]:null
                    },
                    Sw:{
                        F:(indexes!=null && indexes[3]!=undefined)?indexes[3]:null,
                        B:(indexes!=null && indexes[6]!=undefined)?indexes[6]:null
                    },
                    parameters:attachParameters.parameters,
                    required:attachParameters.required,
                    raw:newstr.input
                };

                if($.parser.notaccepted[hex_md5(strSource)]!=undefined){
                    $.parser.notaccepted[hex_md5(strSource)].obj=tmpObj
                }
                return tmpObj;
            }else{
                $.parser.notaccepted[hex_md5(strSource)]={raw:strSource,type:'all_item',obj:null,tmp:null};
                return null;
            }
        },
        checkAlias:function(aliases,strSource,aliasKey){
            var match=null;
            if(aliases!=null){
                for(var i in aliases.alias){
                    var alias=aliases.alias[i].synonym.toLowerCase();
                    var pattern=$.parser.makeRegExp(alias,false);
                    var regexp = new RegExp(pattern, 'i');
                    if(strSource.match(regexp)){
                        if(aliasKey!=undefined){
                            match=aliases[aliasKey];
                        }else{
                            match=aliases.name;
                        }
                    }
                }
            };
            return match;
        },
        getValuesByParameter:function(extraCell,checkedParameters,strSource){
            var attached={
                parameters:new Array,
                required:new Array
            };
            var presets=new Array;
            for(var item in extraCell){
                var pid=parseInt(checkedParameters[item]);
                var getter=extraCell[item].trim();
                if(pid!=4 && pid!=1){
                    if(pid!=null){
                        if(pid==2 || pid==3){
                            var validArray=$.parser.getValidate(getter,pid,attached.parameters);
                            attached.parameters=validArray;
                        }else{
                            var wrapper={
                                parameter_id:(pid!=0)?pid:null,
                                value:$.parser.getValidate(getter,pid,attached.parameters)
                            }
                            attached.parameters.push(wrapper);
                        }
                    }
                }else{
                    var preset={
                        getter:getter
                    }
                    presets[pid]=preset;
                }
            }

            attached.required=$.parser.getByAlgorythm(presets,strSource);

            return attached;
        },
        getByAlgorythm:function(presets,strSource){
            var attached=new Array;
            if(presets[4]!=undefined){
                var matcheasy=$.parser.getValidate(presets[4].getter,4,attached);
                if(matcheasy!=null){
                    var wrapper={
                        parameter_id:4,
                        value:matcheasy
                    }
                    attached.push(wrapper);
                }else{
                    var matchhard=$.parser.getBestMatch(strSource);
                    if(matchhard!=null){
                        var wrapper={
                            parameter_id:4,
                            value:matchhard
                        }
                        attached.push(wrapper);
                    }else{
                        $.parser.notaccepted[hex_md5(strSource)]={raw:strSource,type:'manufacturer',obj:null,tmp:null};
                    }
                }
            }else{
                var match=$.parser.getBestMatch(strSource);
                if(match!=null){
                    var wrapper={
                        parameter_id:4,
                        value:match
                    }
                    attached.push(wrapper);
                }else{
                    $.parser.notaccepted[hex_md5(strSource)]={raw:strSource,type:'manufacturer',obj:null,tmp:null};
                }
            }
            if(attached[0]!=undefined && attached[0].value!=null){
                if(presets[1]!=undefined){
                    var presetModel=$.parser.getModel(presets[1].getter,attached[0].value);
                    if(presetModel!=null){
                        var wrapper={
                            parameter_id:1,
                            value:presetModel
                        }
                        attached.push(wrapper);
                    }else{
                        $.parser.notaccepted[hex_md5(strSource)]={raw:strSource,type:'model',obj:null,tmp:null};
                    }
                }else{
                    var presetModel=$.parser.getModel(strSource,attached[0].value);
                    if(presetModel!=null){
                        var wrapper={
                            parameter_id:1,
                            value:presetModel
                        }
                        attached.push(wrapper);
                    }else{
                        $.parser.notaccepted[hex_md5(strSource)]={raw:strSource,type:'model',obj:null,tmp:null};
                    }
                }
            }
            return attached;
        },
        getBestMatch:function(strSource){
            match=null;
            var manufacturer_preset=$.extraTab.manufacturers[0];
            var left=0;
            var right=parseInt(manufacturer_preset.length-1);
            for(i=0; i<manufacturer_preset.length; i++){
                if(i%2==0){
                    var left_case=manufacturer_preset[left].name.toLowerCase();
                    var left_manufacturer= $.parser.makeRegExp(left_case,false);
                    var regexp = new RegExp(left_manufacturer, 'i');
                    if(strSource.match(regexp)){
                        match=left_case;
                    }else{
                        match=$.parser.checkAlias(manufacturer_preset[left],strSource);
                    }
                    left++;
                }else{
                    var right_case=manufacturer_preset[right].name.toLowerCase();
                    var right_manufacturer= $.parser.makeRegExp(right_case,false);
                    var regexp = new RegExp(right_manufacturer, 'i');
                    if(strSource.match(regexp)){
                        match=right_case;
                    }else{
                        match=$.parser.checkAlias(manufacturer_preset[right],strSource);
                    }
                    right--;
                }
                if(match!=null){
                    return match;
                }
            }
            return null;
        },
        getValidate:function(getter,pid,attached){
            var source=null;
            switch(pid){
                case 21:
                    source=$.parser.getPriceAndCurrency(getter); //fnc
                    break;
                case 22:
                    source=$.parser.getPriceAndCurrency(getter); //fnc
                    break;
                case 23:
                    source=$.parser.getPriceAndCurrency(getter); //fnc
                    break;
                case 24:
                    source=$.parser.getPriceAndCurrency(getter); //fnc
                    break;
                case 2:
                    source=$.parser.getCollectedByNaming(getter,attached); //fnc
                    break;
                case 3:
                    source=$.parser.getCollectedByNaming(getter,attached); //fnc
                    break;
                case 32:
                    source=$.parser.getMatchFrom('technology',getter); //fnc
                    break;
                case 33:
                    source=$.parser.getMatchFrom('spike',getter); //fnc
                    break;
                case 39:
                    source=$.parser.getMatchFrom('marking',getter); //fnc
                    break;
                case 16:
                    source=$.parser.getMatchFrom('color',getter); //fnc
                    break;
                case 4:
                    source=$.parser.getManufacturer(getter); //fnc
                    break;
                default:
                    source=(getter.length>0 && pid!=0)?getter:null;
            }
            return source;
        },
        getPriceAndCurrency:function(source){
            var match=null;
            var currency=$.parser.getMatchFrom('currency',source);
            var regexp = new RegExp('(\\d{2,5})+[\\.,]*(\\d{2})*', 'i');
            var priceMatch=source.match(regexp);
            if(priceMatch!=null){
                var priceLeft=priceMatch[1];
                var priceRight=(priceMatch[2]!=undefined)?priceMatch[2]:'00';
                var price=priceLeft+'.'+priceRight;
                var collected={
                    price:price,
                    currency:currency
                }
                match=collected;
            }
            return match;
        },
        getCollectedByNaming:function(source,attached){
            var match=null;
            if(!$.checkVal(16,attached)){
                match=$.parser.getMatchFrom('color',source);
                var wrapper={
                    parameter_id:16,
                    value:match
                }
                attached.push(wrapper);
                match=null;
            }
            if(!$.checkVal(32,attached)){
                match=$.parser.getMatchFrom('technology',source);
                var wrapper={
                    parameter_id:32,
                    value:match
                }
                attached.push(wrapper);
                match=null;
            }
            if(!$.checkVal(33,attached)){
                match=$.parser.getMatchFrom('spike',source);
                var wrapper={
                    parameter_id:32,
                    value:match
                }
                attached.push(wrapper);
                match=null;
            }
            if(!$.checkVal(39,attached)){
                match=$.parser.getMatchFrom('marking',source);
                var wrapper={
                    parameter_id:39,
                    value:match
                }
                attached.push(wrapper);
                match=null;
            }
            return attached;
        },
        getMatchFrom:function(type,source){
            var match=null;
            var extras=$.extraTab.extras;
            if(extras[type]!=undefined){
                var collection=extras[type];
                for(var item in collection){
                    var pattern=collection[item].name.toLowerCase();
                    var template=$.parser.makeRegExp(pattern,true);
                    var regexp = new RegExp(template, 'i');
                    if(source.match(regexp)){
                        match=collection[item].id;
                    }else{
                        match=$.parser.checkAlias(collection[item],source,'id');
                    }
                    if(match!=null){
                        return match;
                    }
                }
                return match;
            }
            return match;
        },
        getManufacturer:function(source){
            var manufacturer=null;
            var semantic=$.extraTab.semantic_manufacturers;
            var tmp=new Array;
            for(i=0; i<3; i++){
                var digit=source[i].toLowerCase();
                tmp[i]=digit;
            }
            if(semantic[tmp[0]]!=undefined){
                if(semantic[tmp[0]][tmp[1]]!=undefined){
                    if(semantic[tmp[0]][tmp[1]][tmp[2]]!=undefined){
                        manufacturerMatch=semantic[tmp[0]][tmp[1]][tmp[2]];
                        if(typeof manufacturerMatch=="object"){
                            for(var item in manufacturerMatch){
                                var se_manufacturer= $.parser.makeRegExp(manufacturerMatch[item],false);
                                var regexp = new RegExp(se_manufacturer, 'i');
                                if(source.match(regexp)){
                                    manufacturer=manufacturerMatch[item];
                                }
                            }
                        }else{
                            manufacturer=manufacturerMatch;
                        }
                    }else{
                        manufacturer=null;
                        $.parser.callback.trigger('notFound');
                    }
                }
            }
            return manufacturer;
        },
        getModel:function(source,manufacturer){
            var model=null;
            var semantic=$.extraTab.semantic_models;
            if(manufacturer!=null){
                manufacturer=manufacturer.toLowerCase();
                var model_preset=semantic[manufacturer];
                if(model_preset!=undefined){
                    var left=0;
                    var right=parseInt(model_preset.length-1);
                    for(i=0; i<model_preset.length; i++){
                        if(i%2==0){
                            var l_model= $.parser.makeRegExp(model_preset[left].model,false);
                            var regexp = new RegExp(l_model, 'i');
                            if(source.match(regexp)){
                                return model_preset[left];
                            }else{
                                model=$.parser.checkAlias(model_preset[left],source,'model');
                            }
                            left++;
                        }else{
                            var r_model= $.parser.makeRegExp(model_preset[right].model,false);
                            var regexp = new RegExp(r_model, 'i');
                            if(source.match(regexp)){
                                return model_preset[right];
                            }else{
                                model=$.parser.checkAlias(model_preset[right],source,'model');
                            }
                            right--;
                        }
                        if(model!=null){
                            return model;
                        }
                    }
                }else{
                    model=null;
                    $.parser.notaccepted[hex_md5(source)]={raw:source,type:'model',obj:null,tmp:null};
                }
            }
            return model;
        },
        getParameter:function(arr, keys){
            var val=null;
            for(var curr in keys){
                if(arr[keys[curr]]!=undefined){
                    val=arr[keys[curr]];
                }
            }
            return val;
        },
        regulate:function(strSource,domKey,tplKey){
            //var settings=$.parser.collection.settings[domKey];
            var pattern=$.parser.collection.search_templates[tplKey].expression;
            var regexp = new RegExp(pattern, 'i');
            var newstr = strSource.match(regexp);
            return newstr;
        },
        eventLabel:function(str){
            var label=$('#eventLabel');
            label.text(str);
        },
        buildErrorList:function(){
            $('#dropbox').slideUp('200');
            var list=$('#errorList');
            var errors= $.parser.notaccepted;
            for(var item in errors){
                var ruType=new Array;
                ruType['model']='Модель :';
                ruType['manufacturer']='Произв.:';
                ruType['all_item']='Строка :';
                list.append('<li>'+ruType[errors[item].type]+' <span data-id="'+item+'" data-type="'+errors[item].type+'">'+errors[item].raw+'</span><button data-id="'+item+'" class="excl">Исключить</button></li>');
            }
            setTimeout(function(){
                list.slideDown(200);
            },500);
            list.children('li').children('span').callBindForm('.debug_editor',null,false);
            list.children('li').children('button.excl').bind({
                click:function(){
                    var self=$(this);
                    var id=self.attr('data-id');

                    if($.parser.notaccepted[id]!=undefined){
                        delete $.parser.notaccepted[id];
                    }

                    if($.parser.accepted[id]!=undefined){
                        delete $.parser.accepted[id];
                    }
                    $('[data-id="'+id+'"]').unbind();
                    self.parent('li').remove();
                    if(list.children('li').length==0){
                        $('#errorList').slideUp('200');
                    }
                    return false;
                }
            });
            $('button.excl_all').bind({
                click:function(){
                    list.children('li').each(function(){
                        var self=$(this);
                        var id=self.children('button').attr('data-id');
                        $('[data-id="'+id+'"]').unbind();
                        self.remove();
                        if(list.children('li').length==0){
                            $('#errorList').slideUp('200');
                        }
                        if($.parser.notaccepted[id]!=undefined){
                            delete $.parser.notaccepted[id];
                        }

                        if($.parser.accepted[id]!=undefined){
                            delete $.parser.accepted[id];
                        }
                    });
                }
            });
            $('.debug_editor').bind({
                onOpen:function(e,tar){
                    var self=tar;
                    var hashCode=self.attr('data-id');
                    var editor=$('.debug_editor');
                    editor.find('[name="unaccepted[hash]"]').val(hashCode);
                    var unaccepted=editor.find('[name="unaccepted"]');
                    unaccepted.val(self.text());
                    editor.find('.area').hide();
                    var workarea=editor.find('.'+self.attr('data-type'));
                    workarea.show();
                    var interval;

                    unaccepted.mousedown(function(){
                        var selectionNeed=workarea.find('.selectionNeed');
                        selectionNeed.css({'border-color':'red'});
                            interval=setInterval(function(){
                                unaccepted.getSelection(selectionNeed);
                            },400);
                    });
                    unaccepted.mouseup(function(){
                            clearInterval(interval);
                    });

                    editor.find('[name="model[manufacturer_id]"]').bind({
                        change:function(){
                            var selection=$(this).find('option:selected').text().toLowerCase();
                            console.log(selection);
                            if($.extraTab.semantic_models[selection]!=undefined){
                                var list=$.extraTab.semantic_models[selection];
                                editor.find('[name="model[id]"]').buildSelect(list,0,{key:'id',val:'model'});
                            }
                        }
                    });

                }
            });
            $('.debug_editor').bind({
                onSave:function(){
                    var editor=$('.debug_editor');
                    var hashCode=editor.find('[name="unaccepted[hash]"]').val();
                    var unaccepted= $.parser.notaccepted[hashCode];
                    var accepted=$.parser.accepted[hashCode];

                    if(accepted.required[0]!=undefined && accepted.required[1]!=undefined){
                        delete $.parser.notaccepted[hashCode];
                        $('[data-id="'+hashCode+'"]').unbind();
                        $('button[data-id="'+hashCode+'"]').parent('li').remove();
                        if(list.children('li').length==0){
                            $('#errorList').slideUp('200');
                        }
                    }
                }
            });
            $('#nextStep').show();
            $('.add_toDb').bind({
                click:function(){
                    if(list.children('li').length>0){
                        list.children('li').each(function(){
                            var self=$(this);
                            var id=self.children('button').attr('data-id');
                            $('[data-id="'+id+'"]').unbind();
                            self.remove();
                            if(list.children('li').length==0){
                                $('#errorList').slideUp('200');
                            }
                            if($.parser.notaccepted[id]!=undefined){
                                delete $.parser.notaccepted[id];
                            }

                            if($.parser.accepted[id]!=undefined){
                                delete $.parser.accepted[id];
                            }
                        });
                    }
                    var finalLabel=$('#finalLabel');
                    finalLabel.show();
                    finalLabel.text('Подготовка...\n');
                    var arrObj=new Array;
                    for(var item in $.parser.accepted){
                        arrObj.push($.parser.accepted[item]);
                    }

                    delete $.parser.accepted;
                    delete $.parser.collection;

                    var finalJSON=JSON.stringify(arrObj);

                    setTimeout(function(){
                        $('body').jPopup({isActive:true, text:'Выгрузка...\n'});
                        finalLabel.text('Выгрузка...\n');
                        $.post('/wheels/?view=admin_panel&load=api_panel&fnc=add', {fnc: 'price', priceData: finalJSON},
                            function(json){
                                json = new App().ajax(json);
                                if(json.data){
                                    if(json.data.status){
                                        $.jPopupChange('Готово...\n');
                                        finalLabel.text('Готово...\n');
                                        $('body').jPopup({isActive:false});
                                    }
                                }
                            },"json");
                    },1000);
                }
            })
        },
        makeRegExp:function(str,isOnce){
            var regex = new RegExp('\\\+', 'g');
            var newstr=str.replace(regex, '\\+');
            if(isOnce){
                return '(^| |\b)('+newstr+')\b';
            }else{
                return '(^| |\\()('+newstr+').*';
            }
        }


}
});

$.fn.getSelection=function(obj){
    if(this.length!=0 && obj.length!=0){
        var self=$(this).get(0);
        obj.val(self.value.substring(self.selectionStart,self.selectionEnd));
    }
};

$.extend({
    checkVal:function(needle,arr){
        var source=arr;
        for(var item in source){
            if(needle==source[item].parameter_id){
                return true;
            }
        }
        return false;
    }
});

String.prototype.trim = function() {  return this.replace(/^\s+|\s+$/g, '');  }

$(document).ready(function(){

    //console.log(md5("175/70R13	Barum	лето	175/70R13 Barum Brillantis 2 82T	310	8    "));
});