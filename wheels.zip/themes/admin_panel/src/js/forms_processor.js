/**
 * Created with JetBrains PhpStorm.
 * User: noya
 * Date: 03.06.13
 * Time: 16:57
 * To change this template use File | Settings | File Templates.
 */


$.fn.callForm=function(sobj,evt,isSaveAction){
    var saveStatus=false;
    var self=$(this);
    var form=$(sobj);
    var close=form.find('.close');
    var save=form.find('.save');
    $(this).live({
        click:function(){
            console.log('opened');
            form.trigger('onOpen',[$(this)]);
            //$(this).attr('disabled','true');
            form.showInCenter();
            return false;
        }
    });
    close.live({
        click:function(){
            if(saveStatus){
                //self.removeAttr('disabled');
                form.find('input[type="text"]').val('');
                form.fadeOut(200);
            }else{
                if(confirm('Закрыть без сохранения?')){
                    //self.removeAttr('disabled');
                    form.find('input[type="text"]').val('');
                    form.fadeOut(200);
                }
            }
            return false;
        }
    });
    save.live({
        click:function(){
            if(isSaveAction){
                $(document).jPopup({isActive:true});
                $.post(form.attr('action'), form.serialize(),
                function(data,status){
                    if(status=='success'){
                        //self.removeAttr('disabled');
                        form.find('input[type="text"]').val('');
                        form.fadeOut(200);
                        form.trigger('onSave');
                        if(evt!=null){
                            $(document).trigger(evt);
                        }
                    }else{
                        alert('Серверная ошибка!');
                    }
                    $(document).jPopup({isActive:false});
                },"json");
            }else{
                form.find('input[type="text"]').val('');
                form.fadeOut(200);
            }
            return false;
        }
    });
}

$.fn.callBindForm=function(sobj,evt,isSaveAction){
    var saveStatus=false;
    var self=$(this);
    var form=$(sobj);
    var close=form.find('.close');
    var save=form.find('.save');
    $(this).bind({
        click:function(){
            console.log('opened');
            form.trigger('onOpen',[$(this)]);
            //$(this).attr('disabled','true');
            form.showInCenter();
            return false;
        }
    });
    close.bind({
        click:function(){
            if(saveStatus){
                //self.removeAttr('disabled');
                form.find('input[type="text"]').val('');
                form.fadeOut(200);
            }else{
                if(confirm('Закрыть без сохранения?')){
                    //self.removeAttr('disabled');
                    form.find('input[type="text"]').val('');
                    form.fadeOut(200);
                }
            }
            return false;
        }
    });
    save.bind({
        click:function(){
            if(isSaveAction){
                $(document).jPopup({isActive:true});
                $.post(form.attr('action'), form.serialize(),
                function(data,status){
                    if(status=='success'){
                        //self.removeAttr('disabled');
                        form.find('input[type="text"]').val('');
                        form.fadeOut(200);
                        form.trigger('onSave');
                        if(evt!=null){
                            $(document).trigger(evt);
                        }
                    }else{
                        alert('Серверная ошибка!');
                    }
                    $(document).jPopup({isActive:false});
                },"json");
            }else{
                form.trigger('onSave');
                form.find('input[type="text"]').val('');
                form.fadeOut(200);
            }
            return false;
        }
    });
}

$.fn.jPopup=function(option){
    var def_setting={
        text:"loading...",
        confirm:false,
        alert:false,
        isActive:false
    };
    var setting=null;
    if(option!=undefined){
        setting=$.extend(def_setting,option);
    }else{
        setting=def_setting;
    }
    var owner=$(this);
    var layer='<div class="shadow">' +
        '<div class="informer">' +
        '<div class="loading"></div> ' +
        '<span class="text">'+setting.text+'</span>' +
        '</div>' +
        '</div>';
    if(setting.isActive){
        owner.append(layer);
        owner.children('.shadow').children('.informer').showInCenter();
        owner.children('.shadow').fadeIn(500);
    }else{
        owner.children('.shadow').fadeOut(500);
        setTimeout(function(){
            owner.children('.shadow').remove();
        },500);
    }
}

$.extend({
    jPopupChange:function(str){
        $('.informer .text').text(str);
    }
});

$.fn.showInCenter=function(){
    var obj=$(this);
    var wCenter=parseInt(parseInt($(window).width())/2);
    var hCenter=(parseInt(window.scrollY));
    var hhCenter=parseInt(parseInt($(window).height())/2);
    var owCenter=parseInt(parseInt(obj.width())/2);
    var ohCenter=parseInt(parseInt(obj.height())/2);
    var left=(Math.round(wCenter-owCenter)-12);
    var top=Math.round(hhCenter-ohCenter);
    obj.css({'position':'fixed','top':top+'px','left':left+'px'});
    obj.fadeIn(200);
}

$.fn.buildSelect=function(data,selected,alt){
    var select=$(this);
    var counter=0;
    select.html('');
    var key=(alt!=undefined)?alt.key:'key';
    var val=(alt!=undefined)?alt.val:'value';
    for(var item in data){
        var preselect=(data[item][key]==selected)?' selected':'';
        if(counter==0){
            var disselect=(selected==0)?' selected':'';
            select.append('<option value=""'+disselect+' disabled> - </option>');
        }
        select.append('<option value="'+data[item][key]+'"'+preselect+'>'+data[item][val]+'</option>');
        counter++;
    }
}

$.extend({
    updateRequired:function(type,val){
        var editor=$('.debug_editor');
        var hashCode=editor.find('[name="unaccepted[hash]"]').val();
        var unaccepted=$.parser.notaccepted[hashCode].obj.required;
        var accepted=$.parser.accepted[hashCode].required;

        var required=unaccepted;
        var parameter=(type==0)?4:1;
        if(required[type]==undefined){
            var wrapper={
                parameter_id:parameter,
                value:val
            }
            required.push(wrapper);
        }
        $.parser.notaccepted[hashCode].required=required;
        $.parser.accepted[hashCode].required=required;
    }
});

$(document).ready(function(){
    var postProtect=false;
    $('.add_manufacturerPart').bind({
        click:function(){
            if(!postProtect){
                $('body').jPopup({isActive:true});
                postProtect=true;
                var form=$(this).closest('form');
                $.post(form.attr('action'), form.serialize(),
                function(json){
                    json = new App().ajax(json);
                        //self.removeAttr('disabled');
                    form.find('select[name="synonym[manufacturer_id]"]').buildSelect(json.data['list'],0,{key:'id',val:'name'});
                    postProtect=false;
                    $('body').jPopup({isActive:false});

                    $.updateRequired(1,json.data.manufacturer.name.toLowerCase());

                },"json");
            }
            return false;
        }
    });
    $('.add_modelPart').bind({
        click:function(){
            if(!postProtect){
                $('body').jPopup({isActive:true});
                postProtect=true;
                var form=$(this).closest('form');
                $.post(form.attr('action'), form.serialize(),
                function(json){
                    json = new App().ajax(json);
                        //self.removeAttr('disabled');
                    form.find('select[name="synonym[manufacturer_id]"]').buildSelect(json.data['list'],0,{key:'id',val:'name'});
                    postProtect=false;
                    $('body').jPopup({isActive:false});

                    $.updateRequired(1,json.data.model);

                },"json");
            }
            return false;
        }
    });
    $('.synonym_list').callForm('.synonym_table',null,false);
    $('.synonym_table').bind({
        onOpen:function(){
            var self=$(this);
            var table=self.find('table');
            var selector=self.find('[name="synonym[parameter]"]');
            $('body').jPopup({isActive:true});
            $.get('/wheels/?view=admin_panel&load=api_panel&fnc=show&case=synonym_list', function(json){
                json = new App().ajax(json);
                var list=json.data.list;
                selector.buildSelect(list,0);
                selector.bind({
                    change:function(){
                        var val=json.data.values;
                        var selected=parseInt($(this).val());

                        var selectorMod=self.find('[name="synonym[manufacturer_id]"]');
                        var owner=selectorMod.parent();

                        /*if(selected==41 || selected==42){
                            self.find('.parameter_add').hide();
                        }else{
                            self.find('.parameter_add').show();
                        }*/

                        if(selected==41){
                            selectorMod.removeAttr('disabled');
                            selectorMod.buildSelect(json.data.list[42].origin,0,{key:'dict_id',val:'dict_value'});
                            owner.show();
                            var selectedMod=null;
                            selectorMod.bind({
                                change:function(){
                                    selectedMod=$(this).val();
                                    table.html('');
                                    var template='' +
                                        '<tr>' +
                                        '<td>Оригинал</td>' +
                                        '<td>Синоним</td>' +
                                        '<td>Тип</td>' +
                                        '</tr>';
                                    table.append(template);
                                    for(var item in val[selected][selectedMod]){
                                        template='' +
                                            '<tr class="synonym_edit" data-id="'+val[selected][selectedMod][item].id+'" data-action="edit" data-did="'+val[selected][selectedMod][item].dict_id+'" data-type="'+selected+'" data-key="'+item+'">' +
                                            '<td>'+val[selected][selectedMod][item].dict_value+'</td>' +
                                            '<td>'+val[selected][selectedMod][item].synonym+'</td>' +
                                            '<td>'+val[selected][selectedMod][item].parameter_name+'</td>' +
                                            '</tr>';
                                        table.append(template);
                                    }
                                    console.log('changed');
                                }
                            });
                        }else{
                            selectorMod.html('');
                            selectorMod.attr('disabled',true);
                            owner.hide();

                            table.html('');
                            var template='' +
                                '<tr>' +
                                '<td>Оригинал</td>' +
                                '<td>Синоним</td>' +
                                '<td>Тип</td>' +
                                '</tr>';
                            table.append(template);
                            for(var item in val[selected]){
                                template='' +
                                    '<tr class="synonym_edit" data-id="'+val[selected][item].id+'" data-action="edit" data-did="'+val[selected][item].dict_id+'" data-type="'+selected+'" data-key="'+item+'">' +
                                    '<td>'+val[selected][item].dict_value+'</td>' +
                                    '<td>'+val[selected][item].synonym+'</td>' +
                                    '<td>'+val[selected][item].parameter_name+'</td>' +
                                    '</tr>';
                                table.append(template);
                            }
                            console.log('changed');
                        }
                    }
                });
                $('body').jPopup({isActive:false});
            });
        }
    });
    $('.synonym_edit,.synonym_add').callForm('.add_edit_syn','synChange',true);
    $('.add_edit_syn').bind({
        onOpen:function(e,tar){
            $('.synonym_table').jPopup({isActive:true});
            var self=$(this);
            var did=tar.attr('data-did');
            var id=tar.attr('data-id');
            var selectSource=$('.synonym_table').find('[name="synonym[parameter]"]');
            var type=selectSource.val();
            var key=tar.attr('data-key');
            var action=tar.attr('data-action');
            var legend=(action=='edit')?'Изменить':'Добавить';
            self.find('legend').text(legend+' синоним v0.1');
            self.find('[name="fnc"]').val(action);
            self.find('[name="type"]').val(type);
            if(type==41){
                var selectedMod=tar.closest('.widget_editor').find('[name="synonym[manufacturer_id]"]').val();
                if(id!=undefined){
                    console.log('edit');
                    self.find('[name="synonym[id]"]').val(id);
                    var select=self.find('select[name="synonym[dict]"]');
                    $.get('/wheels/?view=admin_panel&load=api_panel&fnc=show&case=synonym_list', function(json){
                        json = new App().ajax(json);
                        var list=json.data.list[type].origin[selectedMod];
                        var values=json.data.values[type][selectedMod][key];
                        self.find('[name="synonym[synonym]"]').val(values.synonym);
                        select.buildSelect(list,did,{key:'dict_id',val:'dict_value'});
                    });
                }else{
                    var select=self.find('select[name="synonym[dict]"]');
                    self.find('[name="synonym[id]"]').val('');
                    if(type.length>0){
                        $.get('/wheels/?view=admin_panel&load=api_panel&fnc=show&case=synonym_list', function(json){
                            json = new App().ajax(json);
                            var list=json.data.list[type].origin[selectedMod];
                            console.log(list,type,selectedMod);
                            select.buildSelect(list,0,{key:'dict_id',val:'dict_value'});
                        });
                    }else{
                        alert('Не выбран тип!');
                    }
                }
            }else{
                if(id!=undefined){
                    console.log('edit');
                    self.find('[name="synonym[id]"]').val(id);
                    var select=self.find('select[name="synonym[dict]"]');
                    $.get('/wheels/?view=admin_panel&load=api_panel&fnc=show&case=synonym_list', function(json){
                        json = new App().ajax(json);
                        var list=json.data.list[type].origin;
                        var values=json.data.values[type][key];
                        self.find('[name="synonym[synonym]"]').val(values.synonym);
                        select.buildSelect(list,did,{key:'dict_id',val:'dict_value'});
                    });
                }else{
                    console.log('add');
                    var select=self.find('select[name="synonym[dict]"]');
                    self.find('[name="synonym[id]"]').val('');
                    if(type.length>0){
                        $.get('/wheels/?view=admin_panel&load=api_panel&fnc=show&case=synonym_list', function(json){
                            json = new App().ajax(json);
                            var list=json.data.list[type].origin;
                            select.buildSelect(list,0,{key:'dict_id',val:'dict_value'});
                        });
                    }else{
                        alert('Не выбран тип!');
                    }
                }
            }
            $('.synonym_table').jPopup({isActive:false});
        },
        onSave:function(){
            $('.synonym_table').trigger('onOpen');
        }
    });
    $('.parameter_add').callForm('.add_edit_param','paramAdd',true);
    $('.add_edit_param').bind({
        onOpen:function(e,tar){
            $('.synonym_table').jPopup({isActive:true});
            var self=$(this);
            var type=tar.closest('.widget_editor').find('[name="synonym[parameter]"]').val();
            type=(type!='')?parseInt(type):null;
            if(type!=null){
                self.find('[name="type"]').val(type);
                if(type==41){
                    var additionalIDValue=tar.closest('.widget_editor').find('[name="synonym[manufacturer_id]"]').val();
                    additionalIDValue=(additionalIDValue!='')?parseInt(additionalIDValue):null;
                    if(additionalIDValue!=null){
                        var additionalID=self.find('[name="dict[manufacturer_id]"]');
                        additionalID.removeAttr('disabled');
                        additionalID.val(additionalIDValue);
                    }else{
                        alert('Вы не выбрали производителя!');
                    }
                }else{
                    var additionalID=self.find('[name="dict[manufacturer_id]"]');
                    additionalID.attr('disabled',true);
                    additionalID.val('');
                }
                self.find('[name="dict[parameter_id]"]').val(type);
            }else{
                alert('Не выбран тип!');
            }
            $('.synonym_table').jPopup({isActive:false});
        },
        onSave:function(){
            $('.synonym_table').trigger('onOpen');
        }
    });
    /*
    *         <legend>Изменить синоним</legend>
     <input type="hidden" name="fnc" value="">
     <input type="hidden" name="synonym[id]" value="">
     <input type="text" name="synonym[synonym]" placeholder="Синоним" />
     <select name="synonym[dict]">
     </select>*/

    /*$('.add_model').bind({
        click:function(){
            var form=$(this).closest('form');
            $.post(form.attr('action'), form.serialize(),
                function(data,status){
                    //self.removeAttr('disabled');
                    alert('Добавлено!');
                },"json");
            return false;
        }
    });*/
});