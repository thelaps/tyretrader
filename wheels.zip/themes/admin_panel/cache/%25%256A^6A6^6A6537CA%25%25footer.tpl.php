<?php /* Smarty version 2.6.26, created on 2013-03-25 21:00:24
         compiled from layout/footer.tpl */ ?>
<!-- End Document
================================================== -->
</body>
</html>