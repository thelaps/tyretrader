<?php /* Smarty version 2.6.26, created on 2013-03-25 20:57:55
         compiled from layout/menu.tpl */ ?>
<div class="container top_menu">
<a href="<?php echo $this->_tpl_vars['baseLink']; ?>
/">Home</a> |
<a href="<?php echo $this->_tpl_vars['baseLink']; ?>
/?view=user">User</a> |
<a href="<?php echo $this->_tpl_vars['baseLink']; ?>
/?view=posts">Posts</a> |
<a href="<?php echo $this->_tpl_vars['baseLink']; ?>
/?view=error">Error</a>
</div>