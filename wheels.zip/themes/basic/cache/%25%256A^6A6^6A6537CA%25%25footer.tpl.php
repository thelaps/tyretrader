<?php /* Smarty version 2.6.26, created on 2013-03-25 20:57:36
         compiled from layout/footer.tpl */ ?>
<!-- End Document
================================================== -->
</body>
</html>