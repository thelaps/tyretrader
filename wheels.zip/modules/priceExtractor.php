<?php
class priceExtractor extends connector{

    private $dbo;

    const DEFAULT_CURRENCY = 2;

    public function DBOExtract($priceData){
        $this->dbo=App::DBO();
        $total = sizeof($priceData);
        $status=false;
        if($total>0){
            $currentPrice = $this->extractPriceByCompany($priceData['company_id']);
            $priceAction = new stdClass();
            $priceAction->insert = array();
            $priceAction->update = array();
            for($i=0; $i<$total; $i++){
                $this->addRowToPriceAction($priceData['company_id'],$priceData[$i],$currentPrice,$priceAction);
            }
            if($this->makeSqlProcess($priceAction)){
                $status=true;
            }
        }

        return array('status'=>$status);
    }

    private function makeSqlProcess($priceAction){
        if(sizeof($priceAction->insert)>0){
            $sqlInsert = 'INSERT INTO wheel_price';
            $sqlInsert .= $this->extractInsert($priceAction->insert);
            print_r($sqlInsert);
        }
        return true;
    }

    private function extractInsert($priceAction){
        $sqlInsert = '';
        $total = sizeof($priceAction);
        $keys = implode(', ', array_keys($priceAction[0]));
        for($i=0; $i<$total; $i++){
            $sqlInsert .= ($i==0)?'('.$keys.') VALUES ':',';
            $priceAction[$i]['company_id'] = 1;
            $this->modifyPricing($priceAction[$i]);
            $sqlInsert .= '('.implode(', ', $priceAction[$i]).')';
        }
        return $sqlInsert;
    }

    private function modifyPricing(&$priceAction){
        for($i=1; $i<5; $i++){
            $priceAction['price_'.$i] = ($priceAction['price_'.$i] instanceof stdClass)?
                $this->recountCurrency($priceAction['price_'.$i]):'NULL';
        }
        return true;
    }

    private function recountCurrency($stdPrice){
        $summary = $stdPrice->price;

        $strPrice = ($summary>0)?$summary:'NULL';

        return '\''.$strPrice.'\'';
    }

    private function addRowToPriceAction($company_id,$row,$currentPrice,&$priceAction){
        if(sizeof($row)>0){
            $model = $this->extractParameter($row->required,1,$row->model);
            $struct = array(
                'price_1' => $this->extractParameter($row->parameters,21),
                'price_2' => $this->extractParameter($row->parameters,22),
                'price_3' => $this->extractParameter($row->parameters,23),
                'price_4' => $this->extractParameter($row->parameters,24),
                'stock_1' => $this->extractParameter($row->parameters,25),
                'stock_2' => $this->extractParameter($row->parameters,26),
                'stock_3' => $this->extractParameter($row->parameters,27),
                'manufacturer_id' => $this->extractParameter($row->parameters,4,$row->manufacturer),
                'model_id' => $model->id,
                'artnum' => $this->extractParameter($row->parameters,5),
                'company_id' => $company_id,
                'date' => time(),
            );

            if(in_array($model->id, $currentPrice)){
                array_push($priceAction->update,$struct);
                return true;
            }else{
                array_push($priceAction->insert,$struct);
                return true;
            }
        }
        return false;
    }

    private function extractParameter($parameters,$needle,$alias = null){
        foreach($parameters as $parameter){
            if($parameter->parameter_id==$needle && $parameter->value!=null){
                return ($this->is_int($parameter->value) || is_object($parameter->value))?$parameter->value:((!empty($parameter->value))?'\''.$parameter->value.'\'':'NULL');
            }
        }
        return ($this->is_int($alias) || is_object($alias))?$alias:((!empty($alias))?'\''.$alias.'\'':'NULL');

    }

    private function is_int($data){
        if(!is_object($data)){
            return preg_match('/^([0-9]+)$/',$data, $match);
        }
        return false;
    }

    private function extractPriceByCompany($company_id){
        $viewData=array();
        $dbo=$this->dbo;
        $query='SELECT model_id FROM wheel_price_com'.$company_id;
        $stmt = $dbo->prepare($query);

        $stmt->execute();

        while($row = $stmt->fetch(PDO::FETCH_OBJ)){
            $viewData[]=$row;
        }
        return $viewData;
    }

}
//Price table
// ID , PRICE1, PRICE2, PRICE3, PRICE4, STOCK1, STOCK2, STOCK3,
// MANUFACTURER_ID, MODEL_ID, ARTNUM, IMG, COMPANY_ID, date
/*
Array
(
    [0] => Array
        (
            [currency] => 2
            [existing] =>
            [R] => 13
            [W] => 175
            [H] => 70
            [I] =>
            [type] => 0
            [manufacturer] => 0
            [model] =>
            [Si] => Array
                (
                    [F] =>
                    [B] => T
                )

            [Sw] => Array
                (
                    [F] =>
                    [B] => 82
                )

            [parameters] => Array
                (
                    [0] => Array
                        (
                            [parameter_id] => 8
                            [value] => 175/70R13
                        )

                    [1] => Array
                        (
                            [parameter_id] =>
                            [value] =>
                        )

                    [2] => Array
                        (
                            [parameter_id] => 16
                            [value] => 54
                        )

                    [3] => Array
                        (
                            [parameter_id] => 32
                            [value] =>
                        )

                    [4] => Array
                        (
                            [parameter_id] => 32
                            [value] =>
                        )

                    [5] => Array
                        (
                            [parameter_id] => 39
                            [value] =>
                        )

                    [6] => Array
                        (
                            [parameter_id] => 21
                            [value] => Array
                                (
                                    [price] => 310.00
                                    [currency] =>
                                )

                        )

                    [7] => Array
                        (
                            [parameter_id] => 25
                            [value] => 8
                        )

                )

            [required] => Array
                (
                    [0] => Array
                        (
                            [parameter_id] => 4
                            [value] => Barum
                        )

                    [1] => Array
                        (
                            [parameter_id] => 1
                            [value] => Array
                                (
                                    [id] => 2288
                                    [model] => Brillantis
                                    [manufacturer_id] => 12
                                    [manufacturer] => Barum
                                    [alias] =>
                                )

                        )

                )

            [raw] => 175/70R13 | Barum | | 175/70R13 Barum Brillantis 2 82T Bleck | 310 | 8
        )

    [1] => Array
        (
            [currency] => 2
            [existing] =>
            [R] => 13
            [W] => 175
            [H] => 70
            [I] =>
            [type] => 0
            [manufacturer] => 0
            [model] =>
            [Si] => Array
                (
                    [F] =>
                    [B] => T
                )

            [Sw] => Array
                (
                    [F] =>
                    [B] => 82
                )

            [parameters] => Array
                (
                    [0] => Array
                        (
                            [parameter_id] => 8
                            [value] => 175/70R13
                        )

                    [1] => Array
                        (
                            [parameter_id] =>
                            [value] =>
                        )

                    [2] => Array
                        (
                            [parameter_id] => 16
                            [value] =>
                        )

                    [3] => Array
                        (
                            [parameter_id] => 32
                            [value] =>
                        )

                    [4] => Array
                        (
                            [parameter_id] => 32
                            [value] =>
                        )

                    [5] => Array
                        (
                            [parameter_id] => 39
                            [value] =>
                        )

                    [6] => Array
                        (
                            [parameter_id] => 21
                            [value] => Array
                                (
                                    [price] => 390.00
                                    [currency] =>
                                )

                        )

                    [7] => Array
                        (
                            [parameter_id] => 25
                            [value] => 25
                        )

                )

            [required] => Array
                (
                    [0] => Array
                        (
                            [parameter_id] => 4
                            [value] => BF Goodrich
                        )

                    [1] => Array
                        (
                            [parameter_id] => 1
                            [value] => Array
                                (
                                    [id] => 2233
                                    [model] => Touring
                                    [manufacturer_id] => 13
                                    [manufacturer] => BF Goodrich
                                    [alias] => Array
                                        (
                                            [0] => Array
                                                (
                                                    [model_id] => 2233
                                                    [synonym] => Toureing
                                                    [manufacturer_id] => 13
                                                )

                                        )

                                )

                        )

                )

            [raw] => 175/70R13 | BFGoodrich | | 175/70R13 BFGoodrich Touring 82T | 390 | 25
        )

    [2] => Array
        (
            [currency] => 2
            [existing] =>
            [R] => 13
            [W] => 175
            [H] => 70
            [I] =>
            [type] => 0
            [manufacturer] => 0
            [model] =>
            [Si] => Array
                (
                    [F] =>
                    [B] => T
                )

            [Sw] => Array
                (
                    [F] =>
                    [B] => 82
                )

            [parameters] => Array
                (
                    [0] => Array
                        (
                            [parameter_id] => 8
                            [value] => 175/70R13
                        )

                    [1] => Array
                        (
                            [parameter_id] =>
                            [value] =>
                        )

                    [2] => Array
                        (
                            [parameter_id] => 16
                            [value] =>
                        )

                    [3] => Array
                        (
                            [parameter_id] => 32
                            [value] =>
                        )

                    [4] => Array
                        (
                            [parameter_id] => 32
                            [value] =>
                        )

                    [5] => Array
                        (
                            [parameter_id] => 39
                            [value] =>
                        )

                    [6] => Array
                        (
                            [parameter_id] => 21
                            [value] => Array
                                (
                                    [price] => 390.00
                                    [currency] =>
                                )

                        )

                    [7] => Array
                        (
                            [parameter_id] => 25
                            [value] => 25
                        )

                )

            [required] => Array
                (
                    [0] => Array
                        (
                            [parameter_id] => 4
                            [value] => BF Goodrich
                        )

                    [1] => Array
                        (
                            [parameter_id] => 1
                            [value] => Touring
                        )

                )

            [raw] => 175/70R13 | BF Gudrich | | 175/70R13 BF Gudrich Toureing 82T | 390 | 25
        )

    [3] => Array
        (
            [currency] => 2
            [existing] =>
            [R] => 13
            [W] => 175
            [H] => 70
            [I] =>
            [type] => 0
            [manufacturer] => 0
            [model] =>
            [Si] => Array
                (
                    [F] =>
                    [B] => S
                )

            [Sw] => Array
                (
                    [F] =>
                    [B] => 82
                )

            [parameters] => Array
                (
                    [0] => Array
                        (
                            [parameter_id] => 8
                            [value] => 175/70R13
                        )

                    [1] => Array
                        (
                            [parameter_id] =>
                            [value] =>
                        )

                    [2] => Array
                        (
                            [parameter_id] => 16
                            [value] =>
                        )

                    [3] => Array
                        (
                            [parameter_id] => 32
                            [value] =>
                        )

                    [4] => Array
                        (
                            [parameter_id] => 32
                            [value] =>
                        )

                    [5] => Array
                        (
                            [parameter_id] => 39
                            [value] =>
                        )

                    [6] => Array
                        (
                            [parameter_id] => 21
                            [value] => Array
                                (
                                    [price] => 620.00
                                    [currency] =>
                                )

                        )

                    [7] => Array
                        (
                            [parameter_id] => 25
                            [value] => 4
                        )

                )

            [required] => Array
                (
                    [0] => Array
                        (
                            [parameter_id] => 4
                            [value] => Bridgestone
                        )

                    [1] => Array
                        (
                            [parameter_id] => 1
                            [value] => Array
                                (
                                    [id] => 4198
                                    [model] => Blizzak Revo-GZ
                                    [manufacturer_id] => 15
                                    [manufacturer] => Bridgestone
                                    [alias] =>
                                )

                        )

                )

            [raw] => 175/70R13 | Bridgestone | | 175/70R13 Bridgestone Blizzak Revo-GZ 82S | 620 | 4
        )

    [4] => Array
        (
            [currency] => 2
            [existing] =>
            [R] => 13
            [W] => 175
            [H] => 70
            [I] =>
            [type] => 0
            [manufacturer] => 0
            [model] =>
            [Si] => Array
                (
                    [F] =>
                    [B] => T
                )

            [Sw] => Array
                (
                    [F] =>
                    [B] => 82
                )

            [parameters] => Array
                (
                    [0] => Array
                        (
                            [parameter_id] => 8
                            [value] => 175/70R13
                        )

                    [1] => Array
                        (
                            [parameter_id] =>
                            [value] =>
                        )

                    [2] => Array
                        (
                            [parameter_id] => 16
                            [value] =>
                        )

                    [3] => Array
                        (
                            [parameter_id] => 32
                            [value] =>
                        )

                    [4] => Array
                        (
                            [parameter_id] => 32
                            [value] =>
                        )

                    [5] => Array
                        (
                            [parameter_id] => 39
                            [value] =>
                        )

                    [6] => Array
                        (
                            [parameter_id] => 21
                            [value] => Array
                                (
                                    [price] => 329.00
                                    [currency] =>
                                )

                        )

                    [7] => Array
                        (
                            [parameter_id] => 25
                            [value] => 16
                        )

                )

            [required] => Array
                (
                    [0] => Array
                        (
                            [parameter_id] => 4
                            [value] => Debica
                        )

                    [1] => Array
                        (
                            [parameter_id] => 1
                            [value] => Navigator
                        )

                )

            [raw] => 175/70R13 | Debica | | 175/70R13 Debica Navigatar 2 82T | 329 | 16
        )

    [5] =>
)

*/